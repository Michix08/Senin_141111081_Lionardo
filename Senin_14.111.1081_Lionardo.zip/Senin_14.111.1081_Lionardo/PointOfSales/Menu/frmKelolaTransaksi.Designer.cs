﻿namespace Latihan_Pos.Menu
{
    partial class frmKelolaTransaksi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtpPembelian = new MetroFramework.Controls.MetroTabPage();
            this.btnTambahPembelian = new MetroFramework.Controls.MetroButton();
            this.txtTotalHargaPembelian = new System.Windows.Forms.TextBox();
            this.txtSubTotalHargaPembelian = new System.Windows.Forms.TextBox();
            this.txtKuantitasPembelian = new System.Windows.Forms.TextBox();
            this.txtHargaBarangPembelian = new System.Windows.Forms.TextBox();
            this.txtBarangPembelian = new System.Windows.Forms.TextBox();
            this.txtKodePembelian = new System.Windows.Forms.TextBox();
            this.txtSupplier = new System.Windows.Forms.TextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseBarangPembelian = new MetroFramework.Controls.MetroButton();
            this.dgvPembelianDetail = new System.Windows.Forms.DataGridView();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseKodePembelian = new MetroFramework.Controls.MetroButton();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseSupplier = new MetroFramework.Controls.MetroButton();
            this.lblSupplier = new MetroFramework.Controls.MetroLabel();
            this.mtcTambahTransaksi = new MetroFramework.Controls.MetroTabControl();
            this.mtpPenjualan = new MetroFramework.Controls.MetroTabPage();
            this.txtTotalHarga = new System.Windows.Forms.TextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtSubTotalHargaPenjualan = new System.Windows.Forms.TextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseBarangPenjualan = new MetroFramework.Controls.MetroButton();
            this.dgvPenjualanDetail = new System.Windows.Forms.DataGridView();
            this.txtKuantitasPenjualan = new System.Windows.Forms.TextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtHargaBarangPenjualan = new System.Windows.Forms.TextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtBarangPenjualan = new System.Windows.Forms.TextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseKodePenjualan = new MetroFramework.Controls.MetroButton();
            this.txtKodePenjualan = new System.Windows.Forms.TextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowseCustomer = new MetroFramework.Controls.MetroButton();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.mtpPembelian.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPembelianDetail)).BeginInit();
            this.mtcTambahTransaksi.SuspendLayout();
            this.mtpPenjualan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPenjualanDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // mtpPembelian
            // 
            this.mtpPembelian.Controls.Add(this.btnTambahPembelian);
            this.mtpPembelian.Controls.Add(this.txtTotalHargaPembelian);
            this.mtpPembelian.Controls.Add(this.txtSubTotalHargaPembelian);
            this.mtpPembelian.Controls.Add(this.txtKuantitasPembelian);
            this.mtpPembelian.Controls.Add(this.txtHargaBarangPembelian);
            this.mtpPembelian.Controls.Add(this.txtBarangPembelian);
            this.mtpPembelian.Controls.Add(this.txtKodePembelian);
            this.mtpPembelian.Controls.Add(this.txtSupplier);
            this.mtpPembelian.Controls.Add(this.metroLabel6);
            this.mtpPembelian.Controls.Add(this.metroLabel7);
            this.mtpPembelian.Controls.Add(this.btnBrowseBarangPembelian);
            this.mtpPembelian.Controls.Add(this.dgvPembelianDetail);
            this.mtpPembelian.Controls.Add(this.metroLabel8);
            this.mtpPembelian.Controls.Add(this.metroLabel10);
            this.mtpPembelian.Controls.Add(this.metroLabel11);
            this.mtpPembelian.Controls.Add(this.btnBrowseKodePembelian);
            this.mtpPembelian.Controls.Add(this.metroLabel12);
            this.mtpPembelian.Controls.Add(this.btnBrowseSupplier);
            this.mtpPembelian.Controls.Add(this.lblSupplier);
            this.mtpPembelian.HorizontalScrollbarBarColor = true;
            this.mtpPembelian.Location = new System.Drawing.Point(4, 35);
            this.mtpPembelian.Name = "mtpPembelian";
            this.mtpPembelian.Size = new System.Drawing.Size(599, 379);
            this.mtpPembelian.TabIndex = 1;
            this.mtpPembelian.Text = "Pembelian";
            this.mtpPembelian.VerticalScrollbarBarColor = true;
            // 
            // btnTambahPembelian
            // 
            this.btnTambahPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTambahPembelian.Location = new System.Drawing.Point(497, 19);
            this.btnTambahPembelian.Name = "btnTambahPembelian";
            this.btnTambahPembelian.Size = new System.Drawing.Size(99, 45);
            this.btnTambahPembelian.TabIndex = 85;
            this.btnTambahPembelian.Text = "Tambah";
            this.btnTambahPembelian.Click += new System.EventHandler(this.btnTambahPembelian_Click);
            // 
            // txtTotalHargaPembelian
            // 
            this.txtTotalHargaPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotalHargaPembelian.Enabled = false;
            this.txtTotalHargaPembelian.Location = new System.Drawing.Point(311, 349);
            this.txtTotalHargaPembelian.Name = "txtTotalHargaPembelian";
            this.txtTotalHargaPembelian.Size = new System.Drawing.Size(285, 20);
            this.txtTotalHargaPembelian.TabIndex = 84;
            // 
            // txtSubTotalHargaPembelian
            // 
            this.txtSubTotalHargaPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSubTotalHargaPembelian.Enabled = false;
            this.txtSubTotalHargaPembelian.Location = new System.Drawing.Point(141, 145);
            this.txtSubTotalHargaPembelian.Name = "txtSubTotalHargaPembelian";
            this.txtSubTotalHargaPembelian.Size = new System.Drawing.Size(247, 20);
            this.txtSubTotalHargaPembelian.TabIndex = 83;
            // 
            // txtKuantitasPembelian
            // 
            this.txtKuantitasPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKuantitasPembelian.Location = new System.Drawing.Point(141, 120);
            this.txtKuantitasPembelian.Name = "txtKuantitasPembelian";
            this.txtKuantitasPembelian.Size = new System.Drawing.Size(247, 20);
            this.txtKuantitasPembelian.TabIndex = 82;
            this.txtKuantitasPembelian.TextChanged += new System.EventHandler(this.txtKuantitasPembelian_TextChanged);
            // 
            // txtHargaBarangPembelian
            // 
            this.txtHargaBarangPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHargaBarangPembelian.Location = new System.Drawing.Point(141, 94);
            this.txtHargaBarangPembelian.Name = "txtHargaBarangPembelian";
            this.txtHargaBarangPembelian.Size = new System.Drawing.Size(247, 20);
            this.txtHargaBarangPembelian.TabIndex = 81;
            this.txtHargaBarangPembelian.TextChanged += new System.EventHandler(this.txtHargaBarangPembelian_TextChanged);
            // 
            // txtBarangPembelian
            // 
            this.txtBarangPembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBarangPembelian.Enabled = false;
            this.txtBarangPembelian.Location = new System.Drawing.Point(141, 69);
            this.txtBarangPembelian.Name = "txtBarangPembelian";
            this.txtBarangPembelian.Size = new System.Drawing.Size(247, 20);
            this.txtBarangPembelian.TabIndex = 80;
            // 
            // txtKodePembelian
            // 
            this.txtKodePembelian.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKodePembelian.Location = new System.Drawing.Point(141, 19);
            this.txtKodePembelian.Name = "txtKodePembelian";
            this.txtKodePembelian.Size = new System.Drawing.Size(247, 20);
            this.txtKodePembelian.TabIndex = 79;
            // 
            // txtSupplier
            // 
            this.txtSupplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSupplier.Enabled = false;
            this.txtSupplier.Location = new System.Drawing.Point(141, 44);
            this.txtSupplier.Name = "txtSupplier";
            this.txtSupplier.Size = new System.Drawing.Size(247, 20);
            this.txtSupplier.TabIndex = 78;
            // 
            // metroLabel6
            // 
            this.metroLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(203, 344);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(102, 25);
            this.metroLabel6.TabIndex = 59;
            this.metroLabel6.Text = "Total Harga";
            // 
            // metroLabel7
            // 
            this.metroLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(3, 140);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(132, 25);
            this.metroLabel7.TabIndex = 57;
            this.metroLabel7.Text = "Subtotal Harga";
            // 
            // btnBrowseBarangPembelian
            // 
            this.btnBrowseBarangPembelian.Location = new System.Drawing.Point(402, 69);
            this.btnBrowseBarangPembelian.Name = "btnBrowseBarangPembelian";
            this.btnBrowseBarangPembelian.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseBarangPembelian.TabIndex = 56;
            this.btnBrowseBarangPembelian.Text = "Browse";
            this.btnBrowseBarangPembelian.Click += new System.EventHandler(this.btnBrowseBarangPembelian_Click);
            // 
            // dgvPembelianDetail
            // 
            this.dgvPembelianDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPembelianDetail.Location = new System.Drawing.Point(3, 171);
            this.dgvPembelianDetail.Name = "dgvPembelianDetail";
            this.dgvPembelianDetail.ReadOnly = true;
            this.dgvPembelianDetail.Size = new System.Drawing.Size(593, 170);
            this.dgvPembelianDetail.TabIndex = 55;
            // 
            // metroLabel8
            // 
            this.metroLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(3, 115);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(84, 25);
            this.metroLabel8.TabIndex = 53;
            this.metroLabel8.Text = "Kuantitas";
            // 
            // metroLabel10
            // 
            this.metroLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(3, 89);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(120, 25);
            this.metroLabel10.TabIndex = 51;
            this.metroLabel10.Text = "Harga Barang";
            // 
            // metroLabel11
            // 
            this.metroLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(3, 64);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(67, 25);
            this.metroLabel11.TabIndex = 49;
            this.metroLabel11.Text = "Barang";
            // 
            // btnBrowseKodePembelian
            // 
            this.btnBrowseKodePembelian.Location = new System.Drawing.Point(402, 19);
            this.btnBrowseKodePembelian.Name = "btnBrowseKodePembelian";
            this.btnBrowseKodePembelian.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseKodePembelian.TabIndex = 48;
            this.btnBrowseKodePembelian.Text = "Browse";
            this.btnBrowseKodePembelian.Click += new System.EventHandler(this.btnBrowseKodePembelian_Click);
            // 
            // metroLabel12
            // 
            this.metroLabel12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(3, 14);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(53, 25);
            this.metroLabel12.TabIndex = 46;
            this.metroLabel12.Text = "Kode";
            // 
            // btnBrowseSupplier
            // 
            this.btnBrowseSupplier.Location = new System.Drawing.Point(402, 44);
            this.btnBrowseSupplier.Name = "btnBrowseSupplier";
            this.btnBrowseSupplier.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseSupplier.TabIndex = 45;
            this.btnBrowseSupplier.Text = "Browse";
            this.btnBrowseSupplier.Click += new System.EventHandler(this.btnBrowseSupplier_Click);
            // 
            // lblSupplier
            // 
            this.lblSupplier.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSupplier.AutoSize = true;
            this.lblSupplier.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblSupplier.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblSupplier.Location = new System.Drawing.Point(3, 39);
            this.lblSupplier.Name = "lblSupplier";
            this.lblSupplier.Size = new System.Drawing.Size(77, 25);
            this.lblSupplier.TabIndex = 42;
            this.lblSupplier.Text = "Supplier";
            // 
            // mtcTambahTransaksi
            // 
            this.mtcTambahTransaksi.Controls.Add(this.mtpPembelian);
            this.mtcTambahTransaksi.Controls.Add(this.mtpPenjualan);
            this.mtcTambahTransaksi.Location = new System.Drawing.Point(24, 64);
            this.mtcTambahTransaksi.Name = "mtcTambahTransaksi";
            this.mtcTambahTransaksi.SelectedIndex = 1;
            this.mtcTambahTransaksi.Size = new System.Drawing.Size(607, 418);
            this.mtcTambahTransaksi.TabIndex = 0;
            // 
            // mtpPenjualan
            // 
            this.mtpPenjualan.Controls.Add(this.metroButton1);
            this.mtpPenjualan.Controls.Add(this.txtTotalHarga);
            this.mtpPenjualan.Controls.Add(this.metroLabel1);
            this.mtpPenjualan.Controls.Add(this.txtSubTotalHargaPenjualan);
            this.mtpPenjualan.Controls.Add(this.metroLabel2);
            this.mtpPenjualan.Controls.Add(this.btnBrowseBarangPenjualan);
            this.mtpPenjualan.Controls.Add(this.dgvPenjualanDetail);
            this.mtpPenjualan.Controls.Add(this.txtKuantitasPenjualan);
            this.mtpPenjualan.Controls.Add(this.metroLabel3);
            this.mtpPenjualan.Controls.Add(this.txtHargaBarangPenjualan);
            this.mtpPenjualan.Controls.Add(this.metroLabel4);
            this.mtpPenjualan.Controls.Add(this.txtBarangPenjualan);
            this.mtpPenjualan.Controls.Add(this.metroLabel5);
            this.mtpPenjualan.Controls.Add(this.btnBrowseKodePenjualan);
            this.mtpPenjualan.Controls.Add(this.txtKodePenjualan);
            this.mtpPenjualan.Controls.Add(this.metroLabel9);
            this.mtpPenjualan.Controls.Add(this.btnBrowseCustomer);
            this.mtpPenjualan.Controls.Add(this.txtCustomer);
            this.mtpPenjualan.Controls.Add(this.metroLabel13);
            this.mtpPenjualan.HorizontalScrollbarBarColor = true;
            this.mtpPenjualan.Location = new System.Drawing.Point(4, 35);
            this.mtpPenjualan.Name = "mtpPenjualan";
            this.mtpPenjualan.Size = new System.Drawing.Size(599, 379);
            this.mtpPenjualan.TabIndex = 0;
            this.mtpPenjualan.Text = "Penjualan";
            this.mtpPenjualan.VerticalScrollbarBarColor = true;
            // 
            // txtTotalHarga
            // 
            this.txtTotalHarga.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotalHarga.Enabled = false;
            this.txtTotalHarga.Location = new System.Drawing.Point(310, 347);
            this.txtTotalHarga.Name = "txtTotalHarga";
            this.txtTotalHarga.Size = new System.Drawing.Size(285, 20);
            this.txtTotalHarga.TabIndex = 79;
            // 
            // metroLabel1
            // 
            this.metroLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(202, 342);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(102, 25);
            this.metroLabel1.TabIndex = 78;
            this.metroLabel1.Text = "Total Harga";
            // 
            // txtSubTotalHargaPenjualan
            // 
            this.txtSubTotalHargaPenjualan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSubTotalHargaPenjualan.Enabled = false;
            this.txtSubTotalHargaPenjualan.Location = new System.Drawing.Point(141, 143);
            this.txtSubTotalHargaPenjualan.Name = "txtSubTotalHargaPenjualan";
            this.txtSubTotalHargaPenjualan.Size = new System.Drawing.Size(249, 20);
            this.txtSubTotalHargaPenjualan.TabIndex = 77;
            // 
            // metroLabel2
            // 
            this.metroLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(3, 138);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(132, 25);
            this.metroLabel2.TabIndex = 76;
            this.metroLabel2.Text = "Subtotal Harga";
            // 
            // btnBrowseBarangPenjualan
            // 
            this.btnBrowseBarangPenjualan.Location = new System.Drawing.Point(401, 67);
            this.btnBrowseBarangPenjualan.Name = "btnBrowseBarangPenjualan";
            this.btnBrowseBarangPenjualan.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseBarangPenjualan.TabIndex = 75;
            this.btnBrowseBarangPenjualan.Text = "Browse";
            this.btnBrowseBarangPenjualan.Click += new System.EventHandler(this.btnBrowseBarang_Click);
            // 
            // dgvPenjualanDetail
            // 
            this.dgvPenjualanDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPenjualanDetail.Location = new System.Drawing.Point(2, 169);
            this.dgvPenjualanDetail.Name = "dgvPenjualanDetail";
            this.dgvPenjualanDetail.ReadOnly = true;
            this.dgvPenjualanDetail.Size = new System.Drawing.Size(593, 170);
            this.dgvPenjualanDetail.TabIndex = 74;
            // 
            // txtKuantitasPenjualan
            // 
            this.txtKuantitasPenjualan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKuantitasPenjualan.Location = new System.Drawing.Point(141, 118);
            this.txtKuantitasPenjualan.Name = "txtKuantitasPenjualan";
            this.txtKuantitasPenjualan.Size = new System.Drawing.Size(249, 20);
            this.txtKuantitasPenjualan.TabIndex = 73;
            this.txtKuantitasPenjualan.TextChanged += new System.EventHandler(this.txtKuantitasPenjualan_TextChanged);
            // 
            // metroLabel3
            // 
            this.metroLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(2, 113);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(84, 25);
            this.metroLabel3.TabIndex = 72;
            this.metroLabel3.Text = "Kuantitas";
            // 
            // txtHargaBarangPenjualan
            // 
            this.txtHargaBarangPenjualan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHargaBarangPenjualan.Location = new System.Drawing.Point(141, 92);
            this.txtHargaBarangPenjualan.Name = "txtHargaBarangPenjualan";
            this.txtHargaBarangPenjualan.Size = new System.Drawing.Size(249, 20);
            this.txtHargaBarangPenjualan.TabIndex = 71;
            this.txtHargaBarangPenjualan.TextChanged += new System.EventHandler(this.txtHargaBarangPenjualan_TextChanged);
            // 
            // metroLabel4
            // 
            this.metroLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(2, 87);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(120, 25);
            this.metroLabel4.TabIndex = 70;
            this.metroLabel4.Text = "Harga Barang";
            // 
            // txtBarangPenjualan
            // 
            this.txtBarangPenjualan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBarangPenjualan.Enabled = false;
            this.txtBarangPenjualan.Location = new System.Drawing.Point(141, 67);
            this.txtBarangPenjualan.Name = "txtBarangPenjualan";
            this.txtBarangPenjualan.Size = new System.Drawing.Size(249, 20);
            this.txtBarangPenjualan.TabIndex = 69;
            // 
            // metroLabel5
            // 
            this.metroLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(2, 62);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(67, 25);
            this.metroLabel5.TabIndex = 68;
            this.metroLabel5.Text = "Barang";
            // 
            // btnBrowseKodePenjualan
            // 
            this.btnBrowseKodePenjualan.Location = new System.Drawing.Point(401, 17);
            this.btnBrowseKodePenjualan.Name = "btnBrowseKodePenjualan";
            this.btnBrowseKodePenjualan.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseKodePenjualan.TabIndex = 67;
            this.btnBrowseKodePenjualan.Text = "Browse";
            this.btnBrowseKodePenjualan.Click += new System.EventHandler(this.btnBrowseKode_Click);
            // 
            // txtKodePenjualan
            // 
            this.txtKodePenjualan.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtKodePenjualan.Location = new System.Drawing.Point(141, 17);
            this.txtKodePenjualan.Name = "txtKodePenjualan";
            this.txtKodePenjualan.Size = new System.Drawing.Size(249, 20);
            this.txtKodePenjualan.TabIndex = 66;
            // 
            // metroLabel9
            // 
            this.metroLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel9.Location = new System.Drawing.Point(2, 12);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(53, 25);
            this.metroLabel9.TabIndex = 65;
            this.metroLabel9.Text = "Kode";
            // 
            // btnBrowseCustomer
            // 
            this.btnBrowseCustomer.Location = new System.Drawing.Point(401, 42);
            this.btnBrowseCustomer.Name = "btnBrowseCustomer";
            this.btnBrowseCustomer.Size = new System.Drawing.Size(90, 20);
            this.btnBrowseCustomer.TabIndex = 64;
            this.btnBrowseCustomer.Text = "Browse";
            this.btnBrowseCustomer.Click += new System.EventHandler(this.btnBrowseCustomer_Click);
            // 
            // txtCustomer
            // 
            this.txtCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomer.Enabled = false;
            this.txtCustomer.Location = new System.Drawing.Point(141, 42);
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.Size = new System.Drawing.Size(249, 20);
            this.txtCustomer.TabIndex = 62;
            // 
            // metroLabel13
            // 
            this.metroLabel13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(2, 37);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(89, 25);
            this.metroLabel13.TabIndex = 61;
            this.metroLabel13.Text = "Customer";
            // 
            // metroButton1
            // 
            this.metroButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.metroButton1.Location = new System.Drawing.Point(496, 17);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(99, 45);
            this.metroButton1.TabIndex = 86;
            this.metroButton1.Text = "Tambah";
            this.metroButton1.Click += new System.EventHandler(this.btnSimpanPenjualan_Click);
            // 
            // frmKelolaTransaksi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 504);
            this.Controls.Add(this.mtcTambahTransaksi);
            this.Name = "frmKelolaTransaksi";
            this.Resizable = false;
            this.Text = "Tambah Transaksi";
            this.mtpPembelian.ResumeLayout(false);
            this.mtpPembelian.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPembelianDetail)).EndInit();
            this.mtcTambahTransaksi.ResumeLayout(false);
            this.mtpPenjualan.ResumeLayout(false);
            this.mtpPenjualan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPenjualanDetail)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabPage mtpPembelian;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroButton btnBrowseBarangPembelian;
        private System.Windows.Forms.DataGridView dgvPembelianDetail;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroButton btnBrowseKodePembelian;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroButton btnBrowseSupplier;
        private MetroFramework.Controls.MetroLabel lblSupplier;
        private MetroFramework.Controls.MetroTabControl mtcTambahTransaksi;
        private MetroFramework.Controls.MetroTabPage mtpPenjualan;
        private System.Windows.Forms.TextBox txtTotalHarga;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.TextBox txtSubTotalHargaPenjualan;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btnBrowseBarangPenjualan;
        private System.Windows.Forms.DataGridView dgvPenjualanDetail;
        private System.Windows.Forms.TextBox txtKuantitasPenjualan;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.TextBox txtHargaBarangPenjualan;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TextBox txtBarangPenjualan;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton btnBrowseKodePenjualan;
        private System.Windows.Forms.TextBox txtKodePenjualan;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroButton btnBrowseCustomer;
        private System.Windows.Forms.TextBox txtCustomer;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.TextBox txtSubTotalHargaPembelian;
        private System.Windows.Forms.TextBox txtKuantitasPembelian;
        private System.Windows.Forms.TextBox txtHargaBarangPembelian;
        private System.Windows.Forms.TextBox txtBarangPembelian;
        private System.Windows.Forms.TextBox txtKodePembelian;
        private System.Windows.Forms.TextBox txtSupplier;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.TextBox txtTotalHargaPembelian;
        private MetroFramework.Controls.MetroButton btnTambahPembelian;
        private MetroFramework.Controls.MetroButton metroButton1;

    }
}